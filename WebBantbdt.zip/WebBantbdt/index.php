<?php include("inc/header.php"); ?>
				<div style="clear:both"></div>
				<!-- mua hang -->
					<?php include("inc/giohang.php"); ?>
				<!-- end mua hang /- -->
				<div style="clear:both"></div>
				<!-- menu top -->
					<?php include("inc/menu_top.php"); ?>
				<!-- end menu top -->	
			
			<div style="clear:both"></div>
			<!-- menu left và nội dung-->
				<?php include("inc/content.php"); ?>
			<!-- end menu left và nội dung-->
		
<?php include("inc/footer.php"); ?>