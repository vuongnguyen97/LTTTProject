<div class="container-flush">
	<nav id="main-menu" style="min-height: 35px !important;">
        <div class="container">
            <div class="row">
                	<div class="col-md-3" style="padding: 0;width: 241px;">
                        <div class="mn-left">
                            <a href="#">
                                <i class="fa fa-home" style="font-size: 25px;"></i>
                                DANH MỤC SẢN PHẨM
                                <img src="images/icon_cat.png" alt="" style="margin-left: 5px; ">
                            </a>
                        </div> <!-- end mn-left -->
                    </div> <!-- end 3 cot -->
                    <div class="col-md-9 row">
                        <div id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="index.php">
                                TRANG CHỦ
                            </a>
                        </li>
                  
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="contact.php">
                                LIÊN HỆ
                            </a>
                        </li>
                     
                       
                    </ul>
                </div>
                    </div> <!-- end 9 cot --> 
            </div> <!-- end row -->
            
        </div>
    </nav>
</div> <!-- end container -->