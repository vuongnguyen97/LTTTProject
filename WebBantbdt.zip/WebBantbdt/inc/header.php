<?php session_start();
//session_unset();
 ?>
<!doctype html>
<html lang="en">

	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<title> WESSITE BÁN THIẾT BỊ ĐIỆN TỬ</title>
		<link rel="icon" href="images/android.ico" />		
		<link href="css/bootstrap.css" rel="stylesheet" />
		<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
		<link href="css/dautrang.css" rel="stylesheet" />
		<link href="css/home/header.css" rel="stylesheet" />
		<link href="css/home/index.css" rel="stylesheet" />	
		<link href="css/home/search.css" rel="stylesheet" />
		<link href="css/home/page.css" rel="stylesheet" />
		<link href="css/home/shoptivi.css" rel="stylesheet" />
		<link href="css/home/setting.css" rel="stylesheet" />
		<link href="css/style.css" rel="stylesheet" />
		<link href="css/style2.css" rel="stylesheet" />
		<link rel="stylesheet" href="css/smoothproducts.css"> 
		<script src="js/slider2.js"></script>


	</head>

	<body id="page-top">
			<header id="header" class="header">
				<!-- top-header -->
				<div class="top-header  hidden-xs">
					<!-- container -->
					<div class="container">
						<p>Hotline: 0973255257 || Địa chỉ: Bến Cát - Bình Dương</p>
					</div><!-- container /- -->
				</div><!-- top-header /- -->
			</header>