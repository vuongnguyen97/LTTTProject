<!-- san pham noi bat -->
      			<div class="noibat">
      				<p class="title2">Sản phẩm cùng nhóm</p>
      				<img src="images/sanpham/ZIDOO H6 PRO/1.jpg" class="img2">
      				<p align="center" style="margin:0;">Egreat A5 Android TV Box 4K HD Player</p>
      				<div class="giaca">
						<span> 500.000đ</span>
						<small style="text-decoration: line-through;color: black">200.000đ</small>
					</div> <!-- end pi-price -->
					<button type="button" class="btn btn-warning center-block">Mua ngay</button>	
      			</div> <!-- end noi bat -->
<!-- end san pham noi bat -->	