﻿	<div style="clear:both;"></div>
	<!-- Footer -->
    <footer class="footer">
        <div class="container-flush">
            <div class="row">
               
                  <div class="col-md-4 mx-auto">

                <!-- Content -->
                <h5 class="font-weight-bold text-uppercase text-center">Footer Content</h5>
                <p>
                    Tại đây chúng tôi chuyên cung cấp các phụ kiện - thiết bị điện tử cho người tiêu dùng
                </p>

            </div>
                <div class="col-md-8 contact-info text-center">
                    <h4>
                        Phụ kiện Việt Nam <span class="text-nowrap"></span>
                    </h4>
                    <p class="text-center">
                        
						Địa chỉ: Hòa Lợi - Bến Cát - Bình Dương<br>
						Điện thoại: 0973255257 - Email: vuongnguyenbn1@gmail.com<br>
						Bản quyền © 2019 
                    </p>
                </div>

            </div>
        </div>
    </footer>
    <!-- End Footer -->
	<!-- Nút back top -->
	<div id="back-to-top" class="back-to-top" data-toggle="tooltip" data-placement="left" title="Trở lên đầu trang"><span class="glyphicon glyphicon-circle-arrow-up text-primary"></span></div>
	<script src="css/bootstrap/js/jquery.min.js"></script>
	<script src="css/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery-2.1.3.min.js"></script>
    <script type="text/javascript" src="js/smoothproducts.min.js"></script>
	<script type="text/javascript" charset="utf-8">
		$("#back-to-top").click(function(){return $("body, html").animate({scrollTop:0},400),!1});
        $(function(){$('[data-toggle="tooltip"]').tooltip()});
	</script>
    
    <script type="text/javascript">
    /* wait for images to load */
    $(window).load(function() {
        $('.sp-wrap').smoothproducts();
    });
    </script>
    </body>
</html>
