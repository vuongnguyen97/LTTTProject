<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li style="background:#1b926c;color:#fff;">
                        <a href="index.php" style="color:#fff;"><i class="fas fa-database"></i> Dashboard</a>
                    </li> 
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo_dm"><i class="fas fa-list-ul icfa"></i> Danh mục bài viết <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo_dm" class="collapse">
                         
                                 <li>
                                <a href="add_baiviet.php">Thêm mới bài viết</a>
                            </li>
                            <li>
                                <a href="list_baiviet.php">Danh sách</a>
                            </li>
                        </ul>
                    </li>                           
                  
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo_sl"><i class="far fa-images icfa"></i> Slider <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo_sl" class="collapse">
                            <li>
                                <a href="add_slider.php">Thêm mới</a>
                            </li>
                            <li>
                                <a href="list_slide.php">Danh sách</a>
                            </li>
                        </ul>
                    </li>   
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo_vd"><i class="fas fa-video icfa"></i> Video <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo_vd" class="collapse">
                            <li>
                                <a href="add_video.php">Thêm mới</a>
                            </li>
                            <li>
                                <a href="list_video.php">Danh sách</a>
                            </li>
                        </ul>
                    </li>  
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo_u"><i class="fa fa-fw fa-user"></i> user <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo_u" class="collapse">
                            <li>
                                <a href="add_user.php">Thêm mới</a>
                            </li>
                            <li>
                                <a href="list_user.php">Danh sách</a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo_sph"><i class="fas fa-cart-plus"></i> Sản phẩm<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo_sph" class="collapse">
                            <li>
                                <a href="add_sanpham.php">Thêm mới</a>
                            </li>
                            <li>
                                <a href="list_sanpham.php">Danh sách</a>
                            </li>
                        </ul>
                    </li>
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo_catelogy"><i class="fas fa-list-ul"></i> Danh mục sản phẩm<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo_catelogy" class="collapse">
                            <li>
                                <a href="add_catelogy.php">Thêm danh mục</a>
                            </li>
                            <li>
                                <a href="list_catelogy.php">Danh sách</a>
                            </li>
                        </ul>
                    </li>
                </ul>

</div>

            